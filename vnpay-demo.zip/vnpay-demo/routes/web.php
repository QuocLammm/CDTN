<?php

use App\Http\Controllers\VNPayController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});


Route::get('/vnpay/payment', [VNPayController::class, 'createPayment'])->name('vnpay.payment');
Route::get('/vnpay/return', [VNPayController::class, 'handleReturn'])->name('vnpay.return');
