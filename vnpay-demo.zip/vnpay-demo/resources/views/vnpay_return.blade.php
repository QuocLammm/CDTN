<!DOCTYPE html>
<html>
<head>
    <title>Kết quả thanh toán</title>
</head>
<body>
<h2>Kết quả thanh toán:</h2>
<pre>{{ print_r($data, true) }}</pre>
</body>
</html>
